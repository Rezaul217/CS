SUPER10 PLY INVESTIGATION — BACKUP SEARCH UPDATE

ZIP CONTENTS
- Original dashboard HTML, CSS, JavaScript, login page, and image assets are retained.
- Apps_Script_Search_Fix.gs contains the Apps Script search-function replacement.
- No file named code.js is included.

SEARCH BEHAVIOR
- Searches the 12 original brand tabs plus the BackuP tab (13 tabs total).
- Original tabs are read using columns A:W.
- BackuP is read using columns A:X; Column A supplies the brand name, and original fields are shifted one column right.
- Backup results show the brand from BackuP Column A with a visible BACKUP badge in the Brand column (for example, DESHI777 [BACKUP]).
- Original-sheet results remain labeled with their regular brand name and no BACKUP badge.
- Search supports English, Bengali, numbers, and mixed text. Up to 300 detailed matches are returned.

INSTALLATION
1. Replace the website's existing script.js with the script.js in this ZIP. Keep index.html, login.html, style.css, and image assets.
2. Open the existing Google Apps Script project connected to the spreadsheet.
3. Keep existing constants (including SPREADSHEET_ID, BRANDS, and any column constants), doGet(), dashboard functions, and all other functions.
4. Replace ONLY searchAllSheets(), normalizeSearchText(), and searchBackuP() with the matching functions in Apps_Script_Search_Fix.gs.
5. Save the Apps Script project.
6. Deploy > Manage deployments > Edit the Web App deployment > select New version > Deploy.
7. Ensure API_URL in script.js points to the /exec URL of that same deployment, and the Web App access setting permits the intended users.

IMPORTANT
- This ZIP has not been connected to or live-tested against your Google Spreadsheet.
- The BackuP tab must be named exactly BackuP, and its data must start at row 2 with brand name in Column A and the shifted fields in columns B:X.
- The dashboard's live connection status now counts 13 tabs (12 brands + BackuP).
