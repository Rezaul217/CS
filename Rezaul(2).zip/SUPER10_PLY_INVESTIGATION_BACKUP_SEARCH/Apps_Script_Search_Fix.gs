/*
 * AGENT INVESTIGATION DASHBOARD — SEARCH PATCH
 * Searches all 12 original brand tabs AND the BackuP tab.
 * Backup layout: A=Brand; original A:W data is shifted to B:X.
 * Replace only searchAllSheets(), normalizeSearchText(), and searchBackuP()
 * in the existing Apps Script project. Keep the existing doGet(), constants,
 * dashboard functions, and all other code.
 */

function searchAllSheets(searchQuery) {
  const query = normalizeSearchText(searchQuery);
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const results = [];
  const sheetStatus = [];
  let scannedSheets = 0;
  let scannedRows = 0;
  let totalMatches = 0;
  const MAX_RESULTS = 300;

  function scanSheet(sheet, brandName, isBackup) {
    if (!sheet) {
      sheetStatus.push({ brand: brandName, success: false, message: "Sheet not found", rowsScanned: 0, matches: 0 });
      return;
    }
    scannedSheets++;
    const lastRow = sheet.getLastRow();
    const requiredColumns = isBackup ? 24 : 23; // A:X backup, A:W original
    const lastColumn = Math.min(requiredColumns, sheet.getMaxColumns());
    if (lastRow < 2 || lastColumn < 1) {
      sheetStatus.push({ brand: brandName, success: true, rowsScanned: 0, matches: 0 });
      return;
    }
    const rows = sheet.getRange(2, 1, lastRow - 1, lastColumn).getDisplayValues();
    scannedRows += rows.length;
    let sheetMatches = 0;
    rows.forEach(function(row, index) {
      const rowText = normalizeSearchText(row.join(" "));
      if (query && rowText.indexOf(query) === -1) return;
      if (!query) return; // empty query is a live-connection check only
      sheetMatches++;
      totalMatches++;
      if (results.length >= MAX_RESULTS) return;
      if (isBackup) {
        results.push({
          brand: String(row[0] || "").trim(), // Backup Column A contains original brand name
          sourceSheet: "BACKUP",
          paymentMethod: String(row[3] || "").trim(), // D
          agentNumber: String(row[4] || "").trim(), // E
          username: String(row[5] || "").trim(), // F
          pgStatus: String(row[9] || "").trim(), // J
          referenceId: String(row[11] || "").trim(), // L
          cashOutNumber: String(row[12] || "").trim(), // M
          amount: String(row[13] || "").trim(), // N
          cartId: String(row[22] || "").trim(), // W
          paymentStatus: String(row[23] || "").trim(), // X
          rowNumber: index + 2,
          rowData: row
        });
      } else {
        results.push({
          brand: brandName,
          sourceSheet: "ORIGINAL",
          paymentMethod: String(row[2] || "").trim(), // C
          agentNumber: String(row[3] || "").trim(), // D
          username: String(row[4] || "").trim(), // E
          pgStatus: String(row[8] || "").trim(), // I
          referenceId: String(row[10] || "").trim(), // K
          cashOutNumber: String(row[11] || "").trim(), // L
          amount: String(row[12] || "").trim(), // M
          cartId: String(row[21] || "").trim(), // V
          paymentStatus: String(row[22] || "").trim(), // W
          rowNumber: index + 2,
          rowData: row
        });
      }
    });
    sheetStatus.push({ brand: brandName, success: true, rowsScanned: rows.length, matches: sheetMatches });
  }

  BRANDS.forEach(function(brand) {
    scanSheet(ss.getSheetByName(brand), brand, false);
  });
  scanSheet(ss.getSheetByName("BackuP"), "BackuP", true);

  return {
    success: true,
    query: String(searchQuery || ""),
    totalMatches: totalMatches,
    returnedMatches: results.length,
    truncated: totalMatches > results.length,
    scannedSheets: scannedSheets,
    connectedSheets: scannedSheets,
    missingSheets: Math.max(0, BRANDS.length + 1 - scannedSheets),
    scannedRows: scannedRows,
    results: results,
    sheetStatus: sheetStatus,
    timestamp: new Date().toISOString()
  };
}

function normalizeSearchText(value) {
  return String(value === null || value === undefined ? "" : value)
    .normalize("NFKC")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .toLocaleLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

function searchBackuP(searchQuery) {
  return searchAllSheets(searchQuery);
}
